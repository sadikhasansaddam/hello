#pragma once
#include <bits/stdc++.h>
#include "1905057_SymbolInfo.h"

using namespace std;

class ScopeTable
{

    const string tagMsg = "ScopeTable::"; // for debugging

    int num_buckets;
    ScopeTable *parent_scopetable = nullptr;
    SymbolInfo **hashtable; // 2D Array of pointers to SymbolInfo.
    int id = 1;
    int scopecount = 0;

public:
    ScopeTable(int n)
    {
        num_buckets = n;
        hashtable = new SymbolInfo *[num_buckets];

        for (int i = 0; i < num_buckets; i++)
        {
            hashtable[i] = nullptr;
        }
    }

    // setter and getter

    void setParentScopeTable(ScopeTable *parent_scopetable)
    {
        this->parent_scopetable = parent_scopetable;
    }

    ScopeTable *getParentScopeTable()
    {
        return parent_scopetable;
    }

    void setId(int id)
    {
        this->id = id;
    }

    int getId()
    {
        return id;
    }

    void setBucketSize(int num_buckets)
    {
        this->num_buckets = num_buckets;
    }

    int getBucketSize()
    {
        return num_buckets;
    }

    int getScopeCount()
    {
        return scopecount;
    }

    void setScopeCount(int scopecount)
    {
        this->scopecount = scopecount;
    }

    // hash function

    int sdbm_hash(string str)
    {
        unsigned int hash = 0;
        unsigned int i = 0;
        unsigned int len = str.length();

        for (i = 0; i < len; i++)
        {
            hash = ((str[i]) + (hash << 6) + (hash << 16) - hash) % num_buckets;
        }

        return hash;
    }

    int calculateHash(string key)
    {
        int index = sdbm_hash(key) % num_buckets;
        return index;
    }

    /// Other functions - insert , lookup , delete , print

    bool insertScopeTable(string name, string type)
    {
        int position = 1;
        int index = calculateHash(name);
        SymbolInfo *newSymbolInfo = new SymbolInfo(name, type);

        if (lookUpScopeTable(name, false) != nullptr)
        {
            cout << "\t" << name << " already exisits in the current ScopeTable" << endl;
            return false;
        }

        if (hashtable[index] == nullptr)
        {
            hashtable[index] = newSymbolInfo;
            // cout << "\tInserted in ScopeTable# " << id << " at position " << index + 1 << ", " << position << endl;
            return true;
        }

        position++;
        SymbolInfo *curr = hashtable[index];

        while (curr->getNextPtr() != nullptr)
        {
            position++;
            curr = curr->getNextPtr();
        }

        curr->setNextPtr(newSymbolInfo);
        // cout << "\tInserted in ScopeTable# " << id << " at position " << index + 1 << ", " << position << endl;
        return true;
    }

    SymbolInfo *lookUpScopeTable(string name, bool show = true)
    {
        int index = calculateHash(name);
        SymbolInfo *curr = hashtable[index];
        int position = 1;

        while (curr != nullptr)
        {
            if (curr->getName() == name)
            {
                if (show)
                   // cout << "\t'" << name << "'"
                        // << " found in ScopeTable# " << id << " at position " << index + 1 << ", " << position << endl;
                return curr;
            }

            position++;
            curr = curr->getNextPtr();
        }
        return nullptr;
    }

    bool deleteScopeTable(string name)
    {
        int position = 1;
        int index = calculateHash(name);
        SymbolInfo *curr = hashtable[index];

        if (lookUpScopeTable(name, false) == nullptr)
        {
            //cout << "\tNot found in the current ScopeTable" << endl;
            return false;
        }

        else if (curr->getName() == name)
        {
            //cout << "\tDeleted "
                // << "'" << name << "'"
                // << " from ScopeTable# " << id << " at position " << index + 1 << ", " << position << endl;
            hashtable[index] = curr->getNextPtr();
            return true;
        }

        SymbolInfo *prev = curr;

        while (curr != nullptr)
        {
            if (curr->getName() == name)
            {
                prev->setNextPtr(curr->getNextPtr());
                //cout << "\tDeleted "
                    // << "'" << name << "'"
                    // << " from ScopeTable# " << id << " at position " << index + 1 << ", " << position << endl;
                delete curr; // memory should be freed
                return true;
            }

            position++;
            prev = curr;
            curr = curr->getNextPtr();
        }

        return false;
    }

    void printScopeTable()
    {
        cout << "\tScopeTable# " << id << endl;

        for (int i = 0; i < num_buckets; i++)
        {
            SymbolInfo *curr = hashtable[i];
            if (curr != nullptr)
            {
                cout << "\t" << i + 1 << "--> ";
                while (curr != nullptr)
                {
                    cout << *curr << " ";
                    curr = curr->getNextPtr();
                }
                cout << endl;
            }
        }
    }

    ~ScopeTable()
    {
        for (int i = 0; i < num_buckets; i++)
        {
            delete hashtable[i];
        }

        delete[] hashtable;
    }
};
