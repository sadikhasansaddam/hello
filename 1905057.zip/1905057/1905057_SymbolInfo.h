#pragma once
#include <bits/stdc++.h>
using namespace std;

class SymbolInfo
{

private:
    string name;
    string type;
    SymbolInfo *next_ptr;
    string dataType;
    string infoType;
    string arrayLength;
    vector<SymbolInfo *> parameterlist;

public:
    SymbolInfo(string name, string type)
    {
        this->name = name;
        this->type = type;
        next_ptr = nullptr;
        dataType = "";
        infoType = "VARIABLE";
        arrayLength = "";
        parameterlist.clear();
    }

    SymbolInfo(SymbolInfo *symbolinfo)
    {
        name = symbolinfo->name;
        type = symbolinfo->type;
        next_ptr = symbolinfo->next_ptr;
        dataType = symbolinfo->dataType;
        infoType = symbolinfo->infoType;
        arrayLength = symbolinfo->arrayLength;
        parameterlist = symbolinfo->parameterlist;
    }

    SymbolInfo(string name, string type, string dataType, string infoType = "VARIABLE", string arrayLength = "")
    {
        this->name = name;
        this->type = type;
        this->next_ptr = nullptr;
        this->dataType = dataType;
        this->infoType = infoType;
        parameterlist.clear();
    }

    SymbolInfo(const SymbolInfo &symbolinfo)
    {
        this->name = symbolinfo.name;
        this->type = symbolinfo.type;
        this->next_ptr = symbolinfo.next_ptr;
        this->dataType = symbolinfo.dataType;
        this->infoType = symbolinfo.infoType;
        this->arrayLength = symbolinfo.arrayLength;
        this->parameterlist = symbolinfo.parameterlist;
    }

    // setter and getter

    void setName(string name)
    {
        this->name = name;
    }

    void setType(string type)
    {
        this->type = type;
    }

    void setNextPtr(SymbolInfo *next_ptr)
    {
        this->next_ptr = next_ptr;
    }

    void setDataType(string datatype)
    {
        this->dataType = datatype;
    }

    void setInfoType(string infotype)
    {
        this->infoType = infotype;
    }

    void setArrayLength(string arraylength)
    {
        this->arrayLength = arraylength;
    }

    void setReturnType(string datatype)
    {
        this->dataType = datatype;
    }
    void setParameterList(vector<SymbolInfo *> parameterlist)
    {
        this->parameterlist = parameterlist;
    }

    string getName()
    {
        return name;
    }

    string getType()
    {
        return type;
    }

    SymbolInfo *getNextPtr()
    {
        return next_ptr;
    }

    string getDataType()
    {
        return dataType;
    }

    string getInfoType()
    {
        return infoType;
    }

    string getArrayLength()
    {
        return arrayLength;
    }

    string getReturnType()
    {
        return dataType;
    }

    vector<SymbolInfo *> getParameterList()
    {
        return parameterlist;
    }

    // extra function for printing purpose
    friend ostream &operator<<(ostream &os, const SymbolInfo &symbolinfo)
    {
        os << "<" << symbolinfo.name << "," << symbolinfo.type << ">";
        return os;
    }

    bool functionFlag()
    {
        return infoType == "FUNCTION_DECLARATION" || infoType == "FUNCTION_DEFINITION";
    }

    bool arrayFlag()
    {
        bool temp = true;
        if (arrayLength == "")
            temp = false;
        return temp;
    }

    void addParameterList(SymbolInfo *parameter)
    {
        parameterlist.push_back(parameter);
    }

    /*
        ~SymbolInfo()
        {
            delete next_ptr;
        }
        */
};

class Node
{
public:
    SymbolInfo *symbolinfo;
    vector<SymbolInfo*> nodes_param_list;
    vector<Node*> childrenlist;
    string addtext = "";
    int startline, lastline;
    bool terminal_flag;

    Node(SymbolInfo *symbolinfo, string addtext)
    {
        this->symbolinfo = symbolinfo;
        this->addtext = addtext;
    }

    Node(SymbolInfo *symbolinfo)
    {
        this->symbolinfo = symbolinfo;
    }

    void addNewText(string text)
    {
        addtext += text;
    }

    void addChildren(Node *node)
    {
        childrenlist.push_back(node);
    }

    void Initialize(int start, int end, bool flag)
    {
        startline = start;
        lastline = end;
        terminal_flag = flag;
    }

    void printChildren(int value, ofstream &parseout)
    {
        if (terminal_flag)
            parseout << addtext << endl;
        else
            parseout << addtext << "<Line: " << startline << "-" << lastline << ">" << endl;

        for (int i = 0; i < childrenlist.size(); i++)
        {
            for (int j = 0; j < value; j++)
            {
                parseout << " ";
            }
            childrenlist[i]->printChildren(value + 1, parseout);
        }
    }
};
