#pragma once
#include<bits/stdc++.h>
#include "1905057_SymbolInfo.h"

using namespace std;

class Node
{
public:
    SymbolInfo *symbolinfo;
    vector<SymbolInfo *> nodes_param_list;
    vector<Node *> childrenlist;
    string addtext = "";
    int startline, lastline;
    bool terminal_flag;

    Node(SymbolInfo *symbolinfo, string addtext)
    {
        this->symbolinfo = symbolinfo;
        this->addtext = addtext;
    }

    Node(SymbolInfo *symbolinfo)
    {
        this->symbolinfo = symbolinfo;
    }

    void addNewText(string text)
    {
        addtext += text;
    }

    void addChildren(Node *node)
    {
        childrenlist.push_back(node);
    }

    void Initialize(int start, int end, bool flag)
    {
        startline = start;
        lastline = end;
        terminal_flag = flag;
    }

    void printChildren(int value, ofstream &parseout)
    {
        if (terminal_flag)
            parseout << addtext << endl;
        else
            parseout << addtext << "<Line: " << startline << "-" << lastline << ">" << endl;

        for (int i = 0; i < childrenlist.size(); i++)
        {
            for (int j = 0; j < value; j++)
            {
                parseout << " ";
            }
            childrenlist[i]->printChildren(value + 1, parseout);
        }
    }
};