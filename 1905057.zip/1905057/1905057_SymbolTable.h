#pragma once
#include<bits/stdc++.h>
#include "1905057_ScopeTable.h"

using namespace std;

class SymbolTable
{

    int num_buckets;
    ScopeTable *currentScopeTable;
    int scope_count;

public:
    SymbolTable(int num_buckets)
    {
        scope_count = 1;
        this->num_buckets = num_buckets;
        currentScopeTable = new ScopeTable(num_buckets);
        currentScopeTable->setId(scope_count);
        // cout << "\tScopeTable# " << currentScopeTable->getId() << " created" << endl;
    }

    ~SymbolTable()
    {

        /* delete currentScopeTable
           pop all the scope tables
           and free resources
        */
        while (currentScopeTable != nullptr)
        {
            ScopeTable *parent = currentScopeTable->getParentScopeTable();
            delete currentScopeTable;
            currentScopeTable = parent;
        }
    }

    void enterScope()
    {

        ScopeTable *scopeTable = new ScopeTable(num_buckets);
        scopeTable->setParentScopeTable(currentScopeTable);
        currentScopeTable = scopeTable;

        if (currentScopeTable->getParentScopeTable() != nullptr)
        {
            currentScopeTable->setId(++scope_count);
        }

        // cout << "\tScopeTable# " << currentScopeTable->getId() << " created" << endl;
    }

    void exitScope()
    {
        if (currentScopeTable == nullptr)
        {
            //cout << "\tNo Current Scope" << endl;
            return;
        }

        if (currentScopeTable->getParentScopeTable() == nullptr)
        {
            //cout << "\tScopeTable# " << currentScopeTable->getId() << " cannot be removed" << endl;
            return;
        }

        ScopeTable *temp = this->currentScopeTable->getParentScopeTable();
        currentScopeTable->setParentScopeTable(nullptr);
        // cout << "\tScopeTable# " << currentScopeTable->getId() << " removed" << endl;
        delete currentScopeTable;
        this->currentScopeTable = temp;
    }

    bool Insert(string name, string type)
    {
        if (currentScopeTable == nullptr)
        {
            currentScopeTable = new ScopeTable(num_buckets);
        }
        return currentScopeTable->insertScopeTable(name, type);
    }

    bool Remove(string name)
    {
        if (currentScopeTable == nullptr)
        {
            return false;
        }
        return currentScopeTable->deleteScopeTable(name);
    }

    SymbolInfo *lookUp(string name)
    {
        if (currentScopeTable == nullptr)
            return nullptr;

        SymbolInfo *symbolinfo = currentScopeTable->lookUpScopeTable(name); // search in current ScopeTable first

        if (symbolinfo == nullptr)
        {
             // if not found in current ScopeTable, search in parent ScopeTable
            ScopeTable *parent_scopetable = currentScopeTable->getParentScopeTable();
            while (parent_scopetable != nullptr)
            {
                symbolinfo = parent_scopetable->lookUpScopeTable(name);
                if (symbolinfo != nullptr) break;
                parent_scopetable = parent_scopetable->getParentScopeTable();
            }
        }
        
        /*
        if (symbolinfo == nullptr)
            cout << "\t'" << name << "'"
                 << " not found in any of the ScopeTables" << endl;
        */
        return symbolinfo;
    }

    void printCurrentScopeTable()
    {
        if (currentScopeTable == nullptr)
        {
            return;
        }
        currentScopeTable->printScopeTable();
    }

    void printAllScopeTables()
    {
        ScopeTable *scopeTable = currentScopeTable;
        while (scopeTable != nullptr)
        {
            scopeTable->printScopeTable();
            scopeTable = scopeTable->getParentScopeTable();
        }
    }

    void deleteAllScopeTables()
    {
        while (currentScopeTable != nullptr)
        {
            ScopeTable *prev = currentScopeTable;
            cout << "\tScopeTable# " << currentScopeTable->getId() << " removed" << endl;
            delete currentScopeTable;
            currentScopeTable = prev->getParentScopeTable();
        }
    }
};
